<div class="flex flex-col">
    <div class="-my-2 overflow-x-auto">
        <div class="py-2 align-middle inline-block min-w-full sm:px-px">
            <div class="shadow-sm relative border border-gray-200 sm:rounded-md sm:overflow-hidden">
                <?php echo e($slot); ?>

            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\splade-sidasi\vendor\protonemedia\laravel-splade\src/../resources/views/table/wrapper.blade.php ENDPATH**/ ?>