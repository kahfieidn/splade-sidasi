<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Rekap Izin Non OSS')); ?>

     <?php $__env->endSlot(); ?>

    <div class="p-4 h-full sm:ml-64">
        <div class="bg-white p-8 border-dashed rounded-lg dark:border-gray-700">
            <h1 class="mb-4 text-4xl font-extrabold leading-none tracking-tight text-gray-900 md:text-3xl lg:text-4xl dark:text-white">Rekapitulasi <span class="underline underline-offset-3 decoration-8 decoration-blue-400 dark:decoration-blue-600">Izin Non OSS</span></h1>

                <div class="relative overflow-x-auto">
                    <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                            <tr>
                                <th scope="col" class="px-6 py-3">
                                    Nama Sektor
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Januari
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Februari
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Maret
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    April
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Mei
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Juni
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Juli
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Agustus
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    September
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Oktober
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    November
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Desember
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sektors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$sektor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">

                                <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                    <?php echo e($sektor->nama_sektor); ?>

                                </th>
                                <td class="px-6 py-4">
                                    <?php echo e($januaris[$key]); ?>

                                </td>
                                <td class="px-6 py-4">
                                    <?php echo e($februaris[$key]); ?>

                                </td>
                                <td class="px-6 py-4">
                                    <?php echo e($marets[$key]); ?>

                                </td>
                                <td class="px-6 py-4">
                                    <?php echo e($aprils[$key]); ?>

                                </td>
                                <td class="px-6 py-4">
                                    <?php echo e($meis[$key]); ?>

                                </td>
                                <td class="px-6 py-4">
                                    <?php echo e($junis[$key]); ?>

                                </td>
                                <td class="px-6 py-4">
                                    <?php echo e($julis[$key]); ?>

                                </td>
                                <td class="px-6 py-4">
                                    <?php echo e($agustuss[$key]); ?>

                                </td>
                                <td class="px-6 py-4">
                                    <?php echo e($septembers[$key]); ?>

                                </td>
                                <td class="px-6 py-4">
                                    <?php echo e($oktobers[$key]); ?>

                                </td>
                                <td class="px-6 py-4">
                                    <?php echo e($novembers[$key]); ?>

                                </td>
                                <td class="px-6 py-4">
                                    <?php echo e($desembers[$key]); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>    
                    </table>
                </div>




        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\splade-sidasi\resources\views/operator/rekap_izin/index.blade.php ENDPATH**/ ?>