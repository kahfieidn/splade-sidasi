<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sanctum.csrf-cookie',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/health-check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.healthCheck',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/execute-solution' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.executeSolution',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/update-config' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.updateConfig',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9rzIHXfcr7jfY5Ml',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_splade/withVueBridge' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'splade.withVueBridge',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_splade/confirmPassword' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'splade.confirmedPasswordStatus',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'splade.confirmPassword',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_splade/fileUpload' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'splade.fileUpload.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'splade.fileUpload.delete',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'homepage',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'profile.edit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'profile.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'profile.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/sektor' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sektor.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'sektor.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/sektor/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sektor.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/izin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'izin.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'izin.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/izin/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'izin.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/lapor-izin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/lapor-izin/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/lapor-izin-import' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin-import.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin-import.import',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/lapor-izin-import/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin-import.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/rekap-izin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rekap-izin.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'rekap-izin.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/rekap-izin/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rekap-izin.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/lapor-izin-oss' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin-oss.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin-oss.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/lapor-izin-oss/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin-oss.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/rekap-izin-oss' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rekap-izin-oss.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'rekap-izin-oss.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/rekap-izin-oss/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rekap-izin-oss.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/data-sektor-oss' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data-sektor-oss.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'data-sektor-oss.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/data-sektor-oss/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data-sektor-oss.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/admin-lapor-izin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-lapor-izin.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin-lapor-izin.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/admin-lapor-izin/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-lapor-izin.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/admin-rekap-izin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-rekap-izin.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin-rekap-izin.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/admin-rekap-izin/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-rekap-izin.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/admin-lapor-izin-oss' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-lapor-izin-oss.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin-lapor-izin-oss.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/admin-lapor-izin-oss/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-lapor-izin-oss.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/admin-data-sektor-oss' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-data-sektor-oss.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin-data-sektor-oss.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/admin-data-sektor-oss/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-data-sektor-oss.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard/admin-rekap-izin-getRekap' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-rekap-izin.getRekap',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/lapor-izin-import/download_format' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin-import.download_format',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pg2hRk9aO3KslCq8',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/forgot-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.request',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'password.email',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reset-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/verify-email' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'verification.notice',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/email/verification-notification' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'verification.send',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/confirm-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.confirm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IDPXJnjHg0jBKEB3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/_(?|dusk/(?|log(?|in/([^/]++)(?:/([^/]++))?(*:51)|out(?:/([^/]++))?(*:75))|user(?:/([^/]++))?(*:101))|splade/(?|eventRedirect/([^/]++)(*:142)|table/(?|action/([^/]++)/([^/]++)/([^/]++)(*:192)|export/([^/]++)/([^/]++)/([^/]++)(*:233))))|/dashboard/(?|sektor/([^/]++)(?|(*:276)|/edit(*:289)|(*:297))|izin/([^/]++)(?|(*:322)|/edit(*:335)|(*:343))|lapor\\-izin(?|/([^/]++)(?|(*:378)|/edit(*:391)|(*:399))|\\-(?|import/([^/]++)(?|(*:431)|/edit(*:444)|(*:452))|oss/([^/]++)(?|(*:476)|/edit(*:489)|(*:497))))|rekap\\-izin(?|/([^/]++)(?|(*:534)|/edit(*:547)|(*:555))|\\-oss/([^/]++)(?|(*:581)|/edit(*:594)|(*:602)))|data\\-sektor\\-oss/([^/]++)(?|(*:641)|/edit(*:654)|(*:662))|admin\\-(?|lapor\\-izin(?|/([^/]++)(?|(*:707)|/edit(*:720)|(*:728))|\\-oss/([^/]++)(?|(*:754)|/edit(*:767)|(*:775)))|rekap\\-izin/([^/]++)(?|(*:808)|/edit(*:821)|(*:829))|data\\-sektor\\-oss/([^/]++)(?|(*:867)|/edit(*:880)|(*:888))))|/reset\\-password/([^/]++)(*:924)|/verify\\-email/([^/]++)/([^/]++)(*:964))/?$}sDu',
    ),
    3 => 
    array (
      51 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dusk.login',
            'guard' => NULL,
          ),
          1 => 
          array (
            0 => 'userId',
            1 => 'guard',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      75 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dusk.logout',
            'guard' => NULL,
          ),
          1 => 
          array (
            0 => 'guard',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      101 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dusk.user',
            'guard' => NULL,
          ),
          1 => 
          array (
            0 => 'guard',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      142 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'splade.eventRedirect',
          ),
          1 => 
          array (
            0 => 'uuid',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      192 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'splade.table.bulkAction',
          ),
          1 => 
          array (
            0 => 'table',
            1 => 'action',
            2 => 'slug',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      233 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'splade.table.export',
          ),
          1 => 
          array (
            0 => 'table',
            1 => 'export',
            2 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      276 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sektor.show',
          ),
          1 => 
          array (
            0 => 'sektor',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      289 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sektor.edit',
          ),
          1 => 
          array (
            0 => 'sektor',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      297 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sektor.update',
          ),
          1 => 
          array (
            0 => 'sektor',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'sektor.destroy',
          ),
          1 => 
          array (
            0 => 'sektor',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      322 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'izin.show',
          ),
          1 => 
          array (
            0 => 'izin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      335 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'izin.edit',
          ),
          1 => 
          array (
            0 => 'izin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      343 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'izin.update',
          ),
          1 => 
          array (
            0 => 'izin',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'izin.destroy',
          ),
          1 => 
          array (
            0 => 'izin',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      378 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin.show',
          ),
          1 => 
          array (
            0 => 'lapor_izin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      391 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin.edit',
          ),
          1 => 
          array (
            0 => 'lapor_izin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      399 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin.update',
          ),
          1 => 
          array (
            0 => 'lapor_izin',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin.destroy',
          ),
          1 => 
          array (
            0 => 'lapor_izin',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      431 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin-import.show',
          ),
          1 => 
          array (
            0 => 'lapor_izin_import',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      444 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin-import.edit',
          ),
          1 => 
          array (
            0 => 'lapor_izin_import',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      452 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin-import.update',
          ),
          1 => 
          array (
            0 => 'lapor_izin_import',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin-import.destroy',
          ),
          1 => 
          array (
            0 => 'lapor_izin_import',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      476 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin-oss.show',
          ),
          1 => 
          array (
            0 => 'lapor_izin_oss',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      489 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin-oss.edit',
          ),
          1 => 
          array (
            0 => 'lapor_izin_oss',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      497 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin-oss.update',
          ),
          1 => 
          array (
            0 => 'lapor_izin_oss',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'lapor-izin-oss.destroy',
          ),
          1 => 
          array (
            0 => 'lapor_izin_oss',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      534 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rekap-izin.show',
          ),
          1 => 
          array (
            0 => 'rekap_izin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      547 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rekap-izin.edit',
          ),
          1 => 
          array (
            0 => 'rekap_izin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      555 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rekap-izin.update',
          ),
          1 => 
          array (
            0 => 'rekap_izin',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'rekap-izin.destroy',
          ),
          1 => 
          array (
            0 => 'rekap_izin',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      581 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rekap-izin-oss.show',
          ),
          1 => 
          array (
            0 => 'rekap_izin_oss',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      594 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rekap-izin-oss.edit',
          ),
          1 => 
          array (
            0 => 'rekap_izin_oss',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      602 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rekap-izin-oss.update',
          ),
          1 => 
          array (
            0 => 'rekap_izin_oss',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'rekap-izin-oss.destroy',
          ),
          1 => 
          array (
            0 => 'rekap_izin_oss',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      641 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data-sektor-oss.show',
          ),
          1 => 
          array (
            0 => 'data_sektor_oss',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      654 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data-sektor-oss.edit',
          ),
          1 => 
          array (
            0 => 'data_sektor_oss',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      662 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'data-sektor-oss.update',
          ),
          1 => 
          array (
            0 => 'data_sektor_oss',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'data-sektor-oss.destroy',
          ),
          1 => 
          array (
            0 => 'data_sektor_oss',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      707 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-lapor-izin.show',
          ),
          1 => 
          array (
            0 => 'admin_lapor_izin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      720 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-lapor-izin.edit',
          ),
          1 => 
          array (
            0 => 'admin_lapor_izin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      728 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-lapor-izin.update',
          ),
          1 => 
          array (
            0 => 'admin_lapor_izin',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin-lapor-izin.destroy',
          ),
          1 => 
          array (
            0 => 'admin_lapor_izin',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      754 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-lapor-izin-oss.show',
          ),
          1 => 
          array (
            0 => 'admin_lapor_izin_oss',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      767 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-lapor-izin-oss.edit',
          ),
          1 => 
          array (
            0 => 'admin_lapor_izin_oss',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      775 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-lapor-izin-oss.update',
          ),
          1 => 
          array (
            0 => 'admin_lapor_izin_oss',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin-lapor-izin-oss.destroy',
          ),
          1 => 
          array (
            0 => 'admin_lapor_izin_oss',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      808 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-rekap-izin.show',
          ),
          1 => 
          array (
            0 => 'admin_rekap_izin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      821 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-rekap-izin.edit',
          ),
          1 => 
          array (
            0 => 'admin_rekap_izin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      829 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-rekap-izin.update',
          ),
          1 => 
          array (
            0 => 'admin_rekap_izin',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin-rekap-izin.destroy',
          ),
          1 => 
          array (
            0 => 'admin_rekap_izin',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      867 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-data-sektor-oss.show',
          ),
          1 => 
          array (
            0 => 'admin_data_sektor_oss',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      880 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-data-sektor-oss.edit',
          ),
          1 => 
          array (
            0 => 'admin_data_sektor_oss',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      888 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-data-sektor-oss.update',
          ),
          1 => 
          array (
            0 => 'admin_data_sektor_oss',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin-data-sektor-oss.destroy',
          ),
          1 => 
          array (
            0 => 'admin_data_sektor_oss',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      924 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.reset',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      964 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'verification.verify',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'hash',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'dusk.login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_dusk/login/{userId}/{guard?}',
      'action' => 
      array (
        'middleware' => 'web',
        'uses' => 'Laravel\\Dusk\\Http\\Controllers\\UserController@login',
        'as' => 'dusk.login',
        'controller' => 'Laravel\\Dusk\\Http\\Controllers\\UserController@login',
        'namespace' => NULL,
        'prefix' => '_dusk',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dusk.logout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_dusk/logout/{guard?}',
      'action' => 
      array (
        'middleware' => 'web',
        'uses' => 'Laravel\\Dusk\\Http\\Controllers\\UserController@logout',
        'as' => 'dusk.logout',
        'controller' => 'Laravel\\Dusk\\Http\\Controllers\\UserController@logout',
        'namespace' => NULL,
        'prefix' => '_dusk',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dusk.user' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_dusk/user/{guard?}',
      'action' => 
      array (
        'middleware' => 'web',
        'uses' => 'Laravel\\Dusk\\Http\\Controllers\\UserController@user',
        'as' => 'dusk.user',
        'controller' => 'Laravel\\Dusk\\Http\\Controllers\\UserController@user',
        'namespace' => NULL,
        'prefix' => '_dusk',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sanctum.csrf-cookie' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'sanctum.csrf-cookie',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'splade.eventRedirect' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_splade/eventRedirect/{uuid}',
      'action' => 
      array (
        'uses' => 'ProtoneMedia\\Splade\\Http\\EventRedirectController@__invoke',
        'controller' => 'ProtoneMedia\\Splade\\Http\\EventRedirectController',
        'as' => 'splade.eventRedirect',
        'middleware' => 
        array (
          0 => 'Illuminate\\Routing\\Middleware\\ValidateSignature',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.healthCheck' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/health-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController',
        'as' => 'ignition.healthCheck',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.executeSolution' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/execute-solution',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController',
        'as' => 'ignition.executeSolution',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.updateConfig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/update-config',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController',
        'as' => 'ignition.updateConfig',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9rzIHXfcr7jfY5Ml' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000006660000000000000000";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::9rzIHXfcr7jfY5Ml',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'splade.withVueBridge' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_splade/withVueBridge',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
        ),
        'uses' => 'ProtoneMedia\\Splade\\Bridge\\ComponentController@__invoke',
        'controller' => 'ProtoneMedia\\Splade\\Bridge\\ComponentController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'splade.withVueBridge',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'splade.confirmedPasswordStatus' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_splade/confirmPassword',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
        ),
        'uses' => 'ProtoneMedia\\Splade\\Http\\ConfirmPasswordController@show',
        'controller' => 'ProtoneMedia\\Splade\\Http\\ConfirmPasswordController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'splade.confirmedPasswordStatus',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'splade.confirmPassword' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_splade/confirmPassword',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
        ),
        'uses' => 'ProtoneMedia\\Splade\\Http\\ConfirmPasswordController@store',
        'controller' => 'ProtoneMedia\\Splade\\Http\\ConfirmPasswordController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'splade.confirmPassword',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'splade.table.bulkAction' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_splade/table/action/{table}/{action}/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'Illuminate\\Routing\\Middleware\\ValidateSignature',
        ),
        'uses' => 'ProtoneMedia\\Splade\\Http\\TableBulkActionController@__invoke',
        'controller' => 'ProtoneMedia\\Splade\\Http\\TableBulkActionController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'splade.table.bulkAction',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'splade.table.export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_splade/table/export/{table}/{export}/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'Illuminate\\Routing\\Middleware\\ValidateSignature',
        ),
        'uses' => 'ProtoneMedia\\Splade\\Http\\TableExportController@__invoke',
        'controller' => 'ProtoneMedia\\Splade\\Http\\TableExportController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'splade.table.export',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'splade.fileUpload.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_splade/fileUpload',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
        ),
        'uses' => 'ProtoneMedia\\Splade\\Http\\FileUploadController@store',
        'controller' => 'ProtoneMedia\\Splade\\Http\\FileUploadController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'splade.fileUpload.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'splade.fileUpload.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '_splade/fileUpload',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
        ),
        'uses' => 'ProtoneMedia\\Splade\\Http\\FileUploadController@delete',
        'controller' => 'ProtoneMedia\\Splade\\Http\\FileUploadController@delete',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'splade.fileUpload.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'homepage' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@homepage',
        'controller' => 'App\\Http\\Controllers\\DashboardController@homepage',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'homepage',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'auth',
          3 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\DashboardController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'profile.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ProfileController@edit',
        'controller' => 'App\\Http\\Controllers\\ProfileController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'profile.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'profile.update' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ProfileController@update',
        'controller' => 'App\\Http\\Controllers\\ProfileController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'profile.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'profile.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ProfileController@destroy',
        'controller' => 'App\\Http\\Controllers\\ProfileController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'profile.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sektor.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/sektor',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'sektor.index',
        'uses' => 'App\\Http\\Controllers\\Operator\\SektorController@index',
        'controller' => 'App\\Http\\Controllers\\Operator\\SektorController@index',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sektor.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/sektor/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'sektor.create',
        'uses' => 'App\\Http\\Controllers\\Operator\\SektorController@create',
        'controller' => 'App\\Http\\Controllers\\Operator\\SektorController@create',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sektor.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dashboard/sektor',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'sektor.store',
        'uses' => 'App\\Http\\Controllers\\Operator\\SektorController@store',
        'controller' => 'App\\Http\\Controllers\\Operator\\SektorController@store',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sektor.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/sektor/{sektor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'sektor.show',
        'uses' => 'App\\Http\\Controllers\\Operator\\SektorController@show',
        'controller' => 'App\\Http\\Controllers\\Operator\\SektorController@show',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sektor.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/sektor/{sektor}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'sektor.edit',
        'uses' => 'App\\Http\\Controllers\\Operator\\SektorController@edit',
        'controller' => 'App\\Http\\Controllers\\Operator\\SektorController@edit',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sektor.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'dashboard/sektor/{sektor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'sektor.update',
        'uses' => 'App\\Http\\Controllers\\Operator\\SektorController@update',
        'controller' => 'App\\Http\\Controllers\\Operator\\SektorController@update',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sektor.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'dashboard/sektor/{sektor}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'sektor.destroy',
        'uses' => 'App\\Http\\Controllers\\Operator\\SektorController@destroy',
        'controller' => 'App\\Http\\Controllers\\Operator\\SektorController@destroy',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'izin.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/izin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'izin.index',
        'uses' => 'App\\Http\\Controllers\\Operator\\IzinController@index',
        'controller' => 'App\\Http\\Controllers\\Operator\\IzinController@index',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'izin.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/izin/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'izin.create',
        'uses' => 'App\\Http\\Controllers\\Operator\\IzinController@create',
        'controller' => 'App\\Http\\Controllers\\Operator\\IzinController@create',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'izin.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dashboard/izin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'izin.store',
        'uses' => 'App\\Http\\Controllers\\Operator\\IzinController@store',
        'controller' => 'App\\Http\\Controllers\\Operator\\IzinController@store',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'izin.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/izin/{izin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'izin.show',
        'uses' => 'App\\Http\\Controllers\\Operator\\IzinController@show',
        'controller' => 'App\\Http\\Controllers\\Operator\\IzinController@show',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'izin.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/izin/{izin}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'izin.edit',
        'uses' => 'App\\Http\\Controllers\\Operator\\IzinController@edit',
        'controller' => 'App\\Http\\Controllers\\Operator\\IzinController@edit',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'izin.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'dashboard/izin/{izin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'izin.update',
        'uses' => 'App\\Http\\Controllers\\Operator\\IzinController@update',
        'controller' => 'App\\Http\\Controllers\\Operator\\IzinController@update',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'izin.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'dashboard/izin/{izin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'izin.destroy',
        'uses' => 'App\\Http\\Controllers\\Operator\\IzinController@destroy',
        'controller' => 'App\\Http\\Controllers\\Operator\\IzinController@destroy',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/lapor-izin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'lapor-izin.index',
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinController@index',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinController@index',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/lapor-izin/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'lapor-izin.create',
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinController@create',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinController@create',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dashboard/lapor-izin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'lapor-izin.store',
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinController@store',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinController@store',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/lapor-izin/{lapor_izin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'lapor-izin.show',
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinController@show',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinController@show',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/lapor-izin/{lapor_izin}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'lapor-izin.edit',
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinController@edit',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinController@edit',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'dashboard/lapor-izin/{lapor_izin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'lapor-izin.update',
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinController@update',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinController@update',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'dashboard/lapor-izin/{lapor_izin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'lapor-izin.destroy',
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinController@destroy',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinController@destroy',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin-import.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/lapor-izin-import',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'lapor-izin-import.index',
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinImportController@index',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinImportController@index',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin-import.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/lapor-izin-import/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'lapor-izin-import.create',
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinImportController@create',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinImportController@create',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin-import.import' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dashboard/lapor-izin-import',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinImportController@import',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinImportController@import',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
        'as' => 'lapor-izin-import.import',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin-import.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/lapor-izin-import/{lapor_izin_import}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'lapor-izin-import.show',
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinImportController@show',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinImportController@show',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin-import.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/lapor-izin-import/{lapor_izin_import}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'lapor-izin-import.edit',
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinImportController@edit',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinImportController@edit',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin-import.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'dashboard/lapor-izin-import/{lapor_izin_import}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'lapor-izin-import.update',
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinImportController@update',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinImportController@update',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin-import.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'dashboard/lapor-izin-import/{lapor_izin_import}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'lapor-izin-import.destroy',
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinImportController@destroy',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinImportController@destroy',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rekap-izin.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/rekap-izin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'rekap-izin.index',
        'uses' => 'App\\Http\\Controllers\\Operator\\RekapIzinController@index',
        'controller' => 'App\\Http\\Controllers\\Operator\\RekapIzinController@index',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rekap-izin.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/rekap-izin/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'rekap-izin.create',
        'uses' => 'App\\Http\\Controllers\\Operator\\RekapIzinController@create',
        'controller' => 'App\\Http\\Controllers\\Operator\\RekapIzinController@create',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rekap-izin.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dashboard/rekap-izin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'rekap-izin.store',
        'uses' => 'App\\Http\\Controllers\\Operator\\RekapIzinController@store',
        'controller' => 'App\\Http\\Controllers\\Operator\\RekapIzinController@store',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rekap-izin.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/rekap-izin/{rekap_izin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'rekap-izin.show',
        'uses' => 'App\\Http\\Controllers\\Operator\\RekapIzinController@show',
        'controller' => 'App\\Http\\Controllers\\Operator\\RekapIzinController@show',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rekap-izin.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/rekap-izin/{rekap_izin}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'rekap-izin.edit',
        'uses' => 'App\\Http\\Controllers\\Operator\\RekapIzinController@edit',
        'controller' => 'App\\Http\\Controllers\\Operator\\RekapIzinController@edit',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rekap-izin.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'dashboard/rekap-izin/{rekap_izin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'rekap-izin.update',
        'uses' => 'App\\Http\\Controllers\\Operator\\RekapIzinController@update',
        'controller' => 'App\\Http\\Controllers\\Operator\\RekapIzinController@update',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rekap-izin.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'dashboard/rekap-izin/{rekap_izin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'rekap-izin.destroy',
        'uses' => 'App\\Http\\Controllers\\Operator\\RekapIzinController@destroy',
        'controller' => 'App\\Http\\Controllers\\Operator\\RekapIzinController@destroy',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin-oss.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/lapor-izin-oss',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'lapor-izin-oss.index',
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinOSSController@index',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinOSSController@index',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin-oss.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/lapor-izin-oss/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'lapor-izin-oss.create',
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinOSSController@create',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinOSSController@create',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin-oss.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dashboard/lapor-izin-oss',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'lapor-izin-oss.store',
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinOSSController@store',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinOSSController@store',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin-oss.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/lapor-izin-oss/{lapor_izin_oss}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'lapor-izin-oss.show',
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinOSSController@show',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinOSSController@show',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin-oss.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/lapor-izin-oss/{lapor_izin_oss}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'lapor-izin-oss.edit',
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinOSSController@edit',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinOSSController@edit',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin-oss.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'dashboard/lapor-izin-oss/{lapor_izin_oss}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'lapor-izin-oss.update',
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinOSSController@update',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinOSSController@update',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin-oss.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'dashboard/lapor-izin-oss/{lapor_izin_oss}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'lapor-izin-oss.destroy',
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinOSSController@destroy',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinOSSController@destroy',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rekap-izin-oss.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/rekap-izin-oss',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'rekap-izin-oss.index',
        'uses' => 'App\\Http\\Controllers\\Operator\\RekapIzinOSSController@index',
        'controller' => 'App\\Http\\Controllers\\Operator\\RekapIzinOSSController@index',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rekap-izin-oss.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/rekap-izin-oss/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'rekap-izin-oss.create',
        'uses' => 'App\\Http\\Controllers\\Operator\\RekapIzinOSSController@create',
        'controller' => 'App\\Http\\Controllers\\Operator\\RekapIzinOSSController@create',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rekap-izin-oss.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dashboard/rekap-izin-oss',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'rekap-izin-oss.store',
        'uses' => 'App\\Http\\Controllers\\Operator\\RekapIzinOSSController@store',
        'controller' => 'App\\Http\\Controllers\\Operator\\RekapIzinOSSController@store',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rekap-izin-oss.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/rekap-izin-oss/{rekap_izin_oss}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'rekap-izin-oss.show',
        'uses' => 'App\\Http\\Controllers\\Operator\\RekapIzinOSSController@show',
        'controller' => 'App\\Http\\Controllers\\Operator\\RekapIzinOSSController@show',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rekap-izin-oss.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/rekap-izin-oss/{rekap_izin_oss}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'rekap-izin-oss.edit',
        'uses' => 'App\\Http\\Controllers\\Operator\\RekapIzinOSSController@edit',
        'controller' => 'App\\Http\\Controllers\\Operator\\RekapIzinOSSController@edit',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rekap-izin-oss.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'dashboard/rekap-izin-oss/{rekap_izin_oss}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'rekap-izin-oss.update',
        'uses' => 'App\\Http\\Controllers\\Operator\\RekapIzinOSSController@update',
        'controller' => 'App\\Http\\Controllers\\Operator\\RekapIzinOSSController@update',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rekap-izin-oss.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'dashboard/rekap-izin-oss/{rekap_izin_oss}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'rekap-izin-oss.destroy',
        'uses' => 'App\\Http\\Controllers\\Operator\\RekapIzinOSSController@destroy',
        'controller' => 'App\\Http\\Controllers\\Operator\\RekapIzinOSSController@destroy',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'data-sektor-oss.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/data-sektor-oss',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'data-sektor-oss.index',
        'uses' => 'App\\Http\\Controllers\\Operator\\DataSektorOSSController@index',
        'controller' => 'App\\Http\\Controllers\\Operator\\DataSektorOSSController@index',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'data-sektor-oss.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/data-sektor-oss/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'data-sektor-oss.create',
        'uses' => 'App\\Http\\Controllers\\Operator\\DataSektorOSSController@create',
        'controller' => 'App\\Http\\Controllers\\Operator\\DataSektorOSSController@create',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'data-sektor-oss.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dashboard/data-sektor-oss',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'data-sektor-oss.store',
        'uses' => 'App\\Http\\Controllers\\Operator\\DataSektorOSSController@store',
        'controller' => 'App\\Http\\Controllers\\Operator\\DataSektorOSSController@store',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'data-sektor-oss.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/data-sektor-oss/{data_sektor_oss}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'data-sektor-oss.show',
        'uses' => 'App\\Http\\Controllers\\Operator\\DataSektorOSSController@show',
        'controller' => 'App\\Http\\Controllers\\Operator\\DataSektorOSSController@show',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'data-sektor-oss.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/data-sektor-oss/{data_sektor_oss}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'data-sektor-oss.edit',
        'uses' => 'App\\Http\\Controllers\\Operator\\DataSektorOSSController@edit',
        'controller' => 'App\\Http\\Controllers\\Operator\\DataSektorOSSController@edit',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'data-sektor-oss.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'dashboard/data-sektor-oss/{data_sektor_oss}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'data-sektor-oss.update',
        'uses' => 'App\\Http\\Controllers\\Operator\\DataSektorOSSController@update',
        'controller' => 'App\\Http\\Controllers\\Operator\\DataSektorOSSController@update',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'data-sektor-oss.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'dashboard/data-sektor-oss/{data_sektor_oss}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:operator',
        ),
        'as' => 'data-sektor-oss.destroy',
        'uses' => 'App\\Http\\Controllers\\Operator\\DataSektorOSSController@destroy',
        'controller' => 'App\\Http\\Controllers\\Operator\\DataSektorOSSController@destroy',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-lapor-izin.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/admin-lapor-izin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-lapor-izin.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\LaporIzinController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\LaporIzinController@index',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-lapor-izin.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/admin-lapor-izin/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-lapor-izin.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\LaporIzinController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\LaporIzinController@create',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-lapor-izin.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dashboard/admin-lapor-izin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-lapor-izin.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\LaporIzinController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\LaporIzinController@store',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-lapor-izin.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/admin-lapor-izin/{admin_lapor_izin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-lapor-izin.show',
        'uses' => 'App\\Http\\Controllers\\Admin\\LaporIzinController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\LaporIzinController@show',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-lapor-izin.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/admin-lapor-izin/{admin_lapor_izin}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-lapor-izin.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\LaporIzinController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\LaporIzinController@edit',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-lapor-izin.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'dashboard/admin-lapor-izin/{admin_lapor_izin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-lapor-izin.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\LaporIzinController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\LaporIzinController@update',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-lapor-izin.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'dashboard/admin-lapor-izin/{admin_lapor_izin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-lapor-izin.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\LaporIzinController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\LaporIzinController@destroy',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-rekap-izin.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/admin-rekap-izin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-rekap-izin.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\RekapIzinController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\RekapIzinController@index',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-rekap-izin.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/admin-rekap-izin/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-rekap-izin.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\RekapIzinController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\RekapIzinController@create',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-rekap-izin.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dashboard/admin-rekap-izin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-rekap-izin.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\RekapIzinController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\RekapIzinController@store',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-rekap-izin.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/admin-rekap-izin/{admin_rekap_izin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-rekap-izin.show',
        'uses' => 'App\\Http\\Controllers\\Admin\\RekapIzinController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\RekapIzinController@show',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-rekap-izin.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/admin-rekap-izin/{admin_rekap_izin}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-rekap-izin.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\RekapIzinController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\RekapIzinController@edit',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-rekap-izin.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'dashboard/admin-rekap-izin/{admin_rekap_izin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-rekap-izin.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\RekapIzinController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\RekapIzinController@update',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-rekap-izin.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'dashboard/admin-rekap-izin/{admin_rekap_izin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-rekap-izin.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\RekapIzinController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\RekapIzinController@destroy',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-lapor-izin-oss.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/admin-lapor-izin-oss',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-lapor-izin-oss.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\LaporIzinOSSController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\LaporIzinOSSController@index',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-lapor-izin-oss.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/admin-lapor-izin-oss/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-lapor-izin-oss.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\LaporIzinOSSController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\LaporIzinOSSController@create',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-lapor-izin-oss.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dashboard/admin-lapor-izin-oss',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-lapor-izin-oss.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\LaporIzinOSSController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\LaporIzinOSSController@store',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-lapor-izin-oss.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/admin-lapor-izin-oss/{admin_lapor_izin_oss}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-lapor-izin-oss.show',
        'uses' => 'App\\Http\\Controllers\\Admin\\LaporIzinOSSController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\LaporIzinOSSController@show',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-lapor-izin-oss.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/admin-lapor-izin-oss/{admin_lapor_izin_oss}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-lapor-izin-oss.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\LaporIzinOSSController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\LaporIzinOSSController@edit',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-lapor-izin-oss.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'dashboard/admin-lapor-izin-oss/{admin_lapor_izin_oss}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-lapor-izin-oss.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\LaporIzinOSSController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\LaporIzinOSSController@update',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-lapor-izin-oss.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'dashboard/admin-lapor-izin-oss/{admin_lapor_izin_oss}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-lapor-izin-oss.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\LaporIzinOSSController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\LaporIzinOSSController@destroy',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-data-sektor-oss.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/admin-data-sektor-oss',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-data-sektor-oss.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\DataSektorOSSController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\DataSektorOSSController@index',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-data-sektor-oss.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/admin-data-sektor-oss/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-data-sektor-oss.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\DataSektorOSSController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\DataSektorOSSController@create',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-data-sektor-oss.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dashboard/admin-data-sektor-oss',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-data-sektor-oss.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\DataSektorOSSController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\DataSektorOSSController@store',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-data-sektor-oss.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/admin-data-sektor-oss/{admin_data_sektor_oss}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-data-sektor-oss.show',
        'uses' => 'App\\Http\\Controllers\\Admin\\DataSektorOSSController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\DataSektorOSSController@show',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-data-sektor-oss.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/admin-data-sektor-oss/{admin_data_sektor_oss}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-data-sektor-oss.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\DataSektorOSSController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\DataSektorOSSController@edit',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-data-sektor-oss.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'dashboard/admin-data-sektor-oss/{admin_data_sektor_oss}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-data-sektor-oss.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\DataSektorOSSController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\DataSektorOSSController@update',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-data-sektor-oss.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'dashboard/admin-data-sektor-oss/{admin_data_sektor_oss}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'as' => 'admin-data-sektor-oss.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\DataSektorOSSController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\DataSektorOSSController@destroy',
        'namespace' => NULL,
        'prefix' => 'dashboard/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-rekap-izin.getRekap' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard/admin-rekap-izin-getRekap',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'role:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RekapIzinController@getRekap',
        'controller' => 'App\\Http\\Controllers\\Admin\\RekapIzinController@getRekap',
        'namespace' => NULL,
        'prefix' => '/dashboard',
        'where' => 
        array (
        ),
        'as' => 'admin-rekap-izin.getRekap',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'lapor-izin-import.download_format' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'lapor-izin-import/download_format',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
        ),
        'uses' => 'App\\Http\\Controllers\\Operator\\LaporIzinImportController@download_format',
        'controller' => 'App\\Http\\Controllers\\Operator\\LaporIzinImportController@download_format',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'lapor-izin-import.download_format',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthenticatedSessionController@create',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthenticatedSessionController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pg2hRk9aO3KslCq8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthenticatedSessionController@store',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthenticatedSessionController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::pg2hRk9aO3KslCq8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.request' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\PasswordResetLinkController@create',
        'controller' => 'App\\Http\\Controllers\\Auth\\PasswordResetLinkController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.request',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.email' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\PasswordResetLinkController@store',
        'controller' => 'App\\Http\\Controllers\\Auth\\PasswordResetLinkController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.email',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.reset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reset-password/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\NewPasswordController@create',
        'controller' => 'App\\Http\\Controllers\\Auth\\NewPasswordController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.reset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'reset-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\NewPasswordController@store',
        'controller' => 'App\\Http\\Controllers\\Auth\\NewPasswordController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'verification.notice' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'verify-email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\EmailVerificationPromptController@__invoke',
        'controller' => 'App\\Http\\Controllers\\Auth\\EmailVerificationPromptController@__invoke',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'verification.notice',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'verification.verify' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'verify-email/{id}/{hash}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'auth',
          3 => 'signed',
          4 => 'throttle:6,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\VerifyEmailController@__invoke',
        'controller' => 'App\\Http\\Controllers\\Auth\\VerifyEmailController@__invoke',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'verification.verify',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'verification.send' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'email/verification-notification',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'auth',
          3 => 'throttle:6,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\EmailVerificationNotificationController@store',
        'controller' => 'App\\Http\\Controllers\\Auth\\EmailVerificationNotificationController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'verification.send',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.confirm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'confirm-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ConfirmablePasswordController@show',
        'controller' => 'App\\Http\\Controllers\\Auth\\ConfirmablePasswordController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.confirm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IDPXJnjHg0jBKEB3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'confirm-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ConfirmablePasswordController@store',
        'controller' => 'App\\Http\\Controllers\\Auth\\ConfirmablePasswordController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::IDPXJnjHg0jBKEB3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\PasswordController@update',
        'controller' => 'App\\Http\\Controllers\\Auth\\PasswordController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'splade',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthenticatedSessionController@destroy',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthenticatedSessionController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
